package br.com.agenda.dao;

import br.com.agenda.factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.ResultSet;
import crudemjava.Contato;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;


public class ContatoDAO {
    public void save(Contato contato) throws Exception{
        
        String sql = "INSERT INTO contatos(nome,idade,email)VALUES(?,?,?)";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try{
            conn = ConnectionFactory.createConnectionToMySQL();
            
            pstm =  (PreparedStatement) conn.prepareStatement(sql);
            pstm.setString(1,contato.getNome());
            pstm.setInt(2,contato.getIdade());
            pstm.setString(3,contato.getEmail());
            
            pstm.execute();
            System.out.println("Contato salvo com sucesso!");
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                if(conn!=null){
                    conn.close();
                }
            }catch(SQLException e){
                e.printStackTrace();
                
            }
        }
            
        
        
        
    }    
    
    public void update(Contato contato){
        
        String sql = "UPDATE contatos SET nome = ?, idade = ?,email = ? "+
                "WHERE  id = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try{
            conn = ConnectionFactory.createConnectionToMySQL();
            
            pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, contato.getNome());
            pstm.setInt(2,contato.getIdade());
            pstm.setString(3, contato.getEmail());
            //Qual o ID do registro que deseja atualizar?
            pstm.setInt(4, contato.getId());
           //Executar a query 
            pstm.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                if(conn!=null){
                    conn.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    public void deleteByID(int id){
        
        String sql = "DELETE FROM contatos WHERE id =?";
        
        Connection conn = null;
        
        PreparedStatement pstm = null; 
        
        try{
            conn = ConnectionFactory.createConnectionToMySQL();
            
            pstm = conn.prepareStatement(sql);
            
            pstm.setInt(1, id);
            
            pstm.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if(pstm != null){
                    pstm.close();
                }
                if(conn != null){
                    conn.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    
    
    
    public List<Contato> getContatos(){
    String sql = "SELECT*FROM contatos";
    
    List<Contato>contatos = new ArrayList<Contato>();
    
    Connection conn = null;
    PreparedStatement pstm = null;
    
    ResultSet rset = null;
    
    try{
        conn = ConnectionFactory.createConnectionToMySQL();
        
        pstm = conn.prepareStatement(sql);
        
        rset= pstm.executeQuery();
        
       while(rset.next()){
           Contato contato = new Contato();
           
           contato.setId(rset.getInt("id"));
           contato.setNome(rset.getString("nome"));
           contato.setIdade(rset.getInt("idade"));
           contato.setEmail(rset.getString("email"));
           
           contatos.add(contato);
       }
       }catch(Exception e){
               e.printStackTrace();
       }finally{
           try{
               if(rset!=null){
                    rset.close();
               }
               
               if(pstm!=null){
                    pstm.close();
               }
               if(conn!=null){
                    conn.close();
               }
           }catch(Exception e){
                e.printStackTrace();
               }
               }
       return contatos;
    }
}

    


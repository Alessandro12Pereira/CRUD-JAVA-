
package br.com.agenda.main;

import br.com.agenda.dao.ContatoDAO;
import crudemjava.Contato;


public class Main {
    public static void main(String[] args) throws Exception {
        
        ContatoDAO contatoDao = new ContatoDAO();
        
        Contato contato = new Contato();
        contato.setNome("Maria Gabriela");
        contato.setIdade(25);
        contato.setEmail("gm174gabi@gmail.com");
        
        //contatoDao.save(contato);
        
        //Atualizar o contato
        Contato c1 = new Contato();
        c1.setNome("Maria Gabriela Dias");
        c1.setIdade(27);
        c1.setEmail("gm174gabi@gmail.com");
        c1.setId(4); //É o numero que está no banco de dados da PK
        
        //contatoDao.update(c1);
        
        //Deletar o contato pelo seu número de ID 
        contatoDao.deleteByID(11);
        //Visualização dos registros do banco de dados TODOS
        
        for(Contato c: contatoDao.getContatos()){
            System.out.println("Contato:"+c.getNome());
        }
        
    }
}
